export class Item {
    Name: string;
    Description: string;
    Id: string;
    Version: string;
    IsPublic: boolean;
    ItemLocation: string;
    CategoryName: string;
}
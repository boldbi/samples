import { Component, Injectable } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { appService } from './app.service'
import { Item } from './app'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [appService]
})

@Injectable()

export class AppComponent {

  public dashboards: Item[];
  public activeDashboard: Item;
  public token: string = "";
  public baseUrl = "";
  public dashboardServerApiUrl = "";
  public dataServiceUrl = "";
  public designerServiceUrl = "";
  public apiHost="http://localhost:5000/coreEmbed/"
  public environment = "enterprise";
  public rootUrl = "http://localhost:5000/bi";
  public siteIdentifier = "site/site1";
  public intermediateDbStatus = false;
  public authorizationUrl="/api/values/getdetails";
  public getDashboardsUrl="/api/values/getdashboards";

  constructor(private _app: appService) {
  }

  ngOnInit() {
  }
}